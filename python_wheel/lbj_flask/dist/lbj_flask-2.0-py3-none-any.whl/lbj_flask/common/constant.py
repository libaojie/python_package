

# 鉴权
APPID = "appid"
USERID = "userid"
USERNAME = "username"
LOGINNAME = "loginname"
SYSLOGID = "sysLogId"
MSG = "msg"
lbj_Time_Begin = "lbjtimebegin"


# header
Authorization = "Authorization"
Application = "Application"
AuthUserName = "AuthUserName"
AuthPassword = "AuthPassword"
UserAgent = "User-Agent"
ApplicationCode = "ApplicationCode"